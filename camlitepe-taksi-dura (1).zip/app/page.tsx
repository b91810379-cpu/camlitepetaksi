'use client'

import { useState, useEffect } from 'react'
import Header from '@/components/header'
import HeroSection from '@/components/hero-section'
import InfoSection from '@/components/info-section'
import MapSection from '@/components/map-section'
import ReviewSection from '@/components/review-section'
import Footer from '@/components/footer'

export default function Page() {
  const [reviews, setReviews] = useState<any[]>([])
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    const savedReviews = localStorage.getItem('taxiReviews')
    if (savedReviews) {
      try {
        setReviews(JSON.parse(savedReviews))
      } catch (e) {
        setReviews([])
      }
    }
  }, [])

  const handleAddReview = (review: any) => {
    const updatedReviews = [review, ...reviews]
    setReviews(updatedReviews)
    if (typeof window !== 'undefined') {
      localStorage.setItem('taxiReviews', JSON.stringify(updatedReviews))
    }
  }

  if (!mounted) {
    return null
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-background to-muted">
      <Header />
      <HeroSection />
      <InfoSection />
      <MapSection />
      <ReviewSection reviews={reviews} onAddReview={handleAddReview} />
      <Footer />
    </main>
  )
}
