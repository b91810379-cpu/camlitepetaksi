'use client'

import { useState } from 'react'
import { Star, Send } from 'lucide-react'

interface Review {
  id: string
  name: string
  rating: number
  comment: string
  date: string
}

interface ReviewSectionProps {
  reviews: Review[]
  onAddReview: (review: Review) => void
}

export default function ReviewSection({ reviews, onAddReview }: ReviewSectionProps) {
  const [formData, setFormData] = useState({
    name: '',
    rating: 5,
    comment: '',
  })
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formData.name.trim() || !formData.comment.trim()) {
      alert('Lütfen adınız ve yorumunuzu giriniz')
      return
    }

    const newReview: Review = {
      id: Date.now().toString(),
      name: formData.name,
      rating: formData.rating,
      comment: formData.comment,
      date: new Date().toLocaleDateString('tr-TR'),
    }

    onAddReview(newReview)
    setFormData({ name: '', rating: 5, comment: '' })
    setSubmitted(true)
    setTimeout(() => setSubmitted(false), 3000)
  }

  const averageRating = reviews.length > 0 
    ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)
    : 0

  return (
    <section className="py-12 md:py-16 bg-white">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-4xl font-black text-secondary mb-2 text-center tracking-tight">Müşteri Yorumları</h2>
        <p className="text-center text-secondary font-bold mb-8 text-lg">
          Hizmetimiz hakkında deneyimlerinizi paylaşın
        </p>

        {/* Yorum Formu */}
        <div className="bg-gradient-to-br from-primary/15 to-primary/5 rounded-lg p-8 mb-12 border-2 border-primary">
          <h3 className="text-3xl font-black text-secondary mb-6">Yorum Yapın</h3>
          
          {submitted && (
            <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg text-green-800">
              ✓ Yorumunuz başarıyla eklendi! Teşekkürler.
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* İsim */}
            <div>
              <label className="block text-secondary font-black mb-3 text-lg">Adınız *</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Adınız"
                className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>

            {/* Puan */}
            <div>
              <label className="block text-secondary font-black mb-3 text-lg">Puan *</label>
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setFormData({ ...formData, rating: star })}
                    className="transition-transform hover:scale-110"
                  >
                    <Star
                      size={32}
                      className={star <= formData.rating ? 'fill-primary text-primary' : 'text-muted-foreground'}
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Yorum */}
            <div>
              <label className="block text-secondary font-black mb-3 text-lg">Yorum *</label>
              <textarea
                value={formData.comment}
                onChange={(e) => setFormData({ ...formData, comment: e.target.value })}
                placeholder="Yorumunuzu yazınız..."
                rows={4}
                className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary resize-none"
              />
            </div>

            {/* Gönder Butonu */}
            <button
              type="submit"
              className="w-full bg-primary text-secondary font-black py-4 rounded-lg hover:bg-opacity-90 transition-all flex items-center justify-center gap-2 text-lg shadow-lg hover:shadow-xl"
            >
              <Send size={22} />
              Yorum Gönder
            </button>
          </form>
        </div>

        {/* Yorumlar Listesi */}
        <div>
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-3xl font-black text-secondary">
              Tüm Yorumlar ({reviews.length})
            </h3>
            <div className="flex items-center gap-2">
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    size={20}
                    className={star <= Math.round(Number(averageRating)) ? 'fill-primary text-primary' : 'text-muted-foreground'}
                  />
                ))}
              </div>
              <span className="text-lg font-bold text-secondary">{averageRating}</span>
            </div>
          </div>

          {reviews.length === 0 ? (
            <div className="text-center py-12 bg-muted rounded-lg">
              <p className="text-muted-foreground text-lg">Henüz yorum yapılmamış. İlk yorum yapan siz olun!</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {reviews.map((review) => (
                <div
                  key={review.id}
                  className="bg-card border-2 border-primary rounded-lg p-6 hover:shadow-lg transition-all hover:bg-primary/5"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h4 className="font-black text-secondary text-xl">{review.name}</h4>
                      <p className="text-sm text-primary font-bold">{review.date}</p>
                    </div>
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          size={16}
                          className={star <= review.rating ? 'fill-primary text-primary' : 'text-muted-foreground'}
                        />
                      ))}
                    </div>
                  </div>
                  <p className="text-secondary font-semibold text-base">{review.comment}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  )
}
