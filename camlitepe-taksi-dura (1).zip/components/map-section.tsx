'use client'

import { useEffect } from 'react'

export default function MapSection() {
  useEffect(() => {
    // Google Maps script yükleme
    const script = document.createElement('script')
    script.src = 'https://maps.googleapis.com/maps/api/js?key=AIzaSyDummyKeyForDemo&libraries=marker'
    script.async = true
    script.defer = true
    document.head.appendChild(script)
  }, [])

  return (
    <section className="py-12 md:py-16 bg-muted">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-secondary mb-8 text-center">Bizi Haritada Bulun</h2>
        
        <div className="rounded-lg overflow-hidden shadow-lg h-96 md:h-[500px]">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3151.835434509374!2d41.13467231525423!3d37.88434527177926!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x400851e3ef3ffd03%3A0x3c3c3c3c3c3c3c3c!2s%C3%87aml%C4%B1tepe%2C%20Batman!5e0!3m2!1str!2str!4v1234567890"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>

        <div className="mt-8 bg-white p-6 rounded-lg shadow">
          <h3 className="text-xl font-bold text-secondary mb-4">Konum Detayları</h3>
          <div className="space-y-2 text-secondary">
            <p><strong>Durağın Adı:</strong> Çamlıtepe Taksi Durağı</p>
            <p><strong>Adres:</strong> Çamlıtepe Mahallesi, Dünya Hastanesi Önü, 72060 Batman Merkez/Batman</p>
            <p><strong>Harita Linki:</strong> <a href="https://maps.google.com/?q=Çamlıtepe+Batman" target="_blank" rel="noopener noreferrer" className="text-primary font-semibold hover:underline">Google Harita&apos;da Aç</a></p>
          </div>
        </div>
      </div>
    </section>
  )
}
