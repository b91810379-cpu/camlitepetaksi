import { Phone, MapPin, Clock } from 'lucide-react'

export default function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-secondary text-primary-foreground">
      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* İşletme Bilgisi */}
          <div>
            <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center text-secondary font-bold">
                T
              </div>
              Çamlıtepe Taksi
            </h3>
            <p className="opacity-90">
              Batman Merkez bölgesinde güvenilir ve profesyonel taksi hizmeti sunuyoruz.
            </p>
          </div>

          {/* Hızlı Linkler */}
          <div>
            <h4 className="text-lg font-bold mb-4">Hızlı Linkler</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className="opacity-90 hover:opacity-100 transition-opacity">
                  Anasayfa
                </a>
              </li>
              <li>
                <a href="#yorumlar" className="opacity-90 hover:opacity-100 transition-opacity">
                  Yorumlar
                </a>
              </li>
              <li>
                <a href="#harita" className="opacity-90 hover:opacity-100 transition-opacity">
                  Harita
                </a>
              </li>
              <li>
                <a href="#iletisim" className="opacity-90 hover:opacity-100 transition-opacity">
                  İletişim
                </a>
              </li>
            </ul>
          </div>

          {/* İletişim Bilgisi */}
          <div>
            <h4 className="text-lg font-bold mb-4">İletişim</h4>
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <Phone size={18} />
                <span>0530 637 84 49</span>
              </div>
              <div className="flex items-start gap-3">
                <MapPin size={18} className="mt-1" />
                <span className="text-sm">
                  Çamlıtepe Mahallesi, Dünya Hastanesi Önü<br/>
                  72060 Batman Merkez
                </span>
              </div>
              <div className="flex items-center gap-3">
                <Clock size={18} />
                <span>7/24 Açık</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-primary-foreground/20 pt-8">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <p className="opacity-75 text-sm">
              &copy; {currentYear} Çamlıtepe Taksi Durağı. Tüm hakları saklıdır.
            </p>
            <p className="opacity-75 text-sm">
              Tasarım ve Geliştirme: v0
            </p>
          </div>
        </div>
      </div>
    </footer>
  )
}
