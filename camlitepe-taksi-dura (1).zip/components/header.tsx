import { Phone, MessageCircle } from 'lucide-react'

export default function Header() {
  const phoneNumber = '05306378449'
  const whatsappNumber = '905306378449'
  const message = 'Merhaba, taksi çağırmak istiyorum'

  return (
    <header className="sticky top-0 z-50 bg-secondary text-primary-foreground shadow-lg">
      <div className="max-w-6xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 bg-primary rounded-full flex items-center justify-center font-bold text-secondary text-lg">
              T
            </div>
            <div>
              <h1 className="text-2xl font-black tracking-tight">Çamlıtepe Taksi</h1>
              <p className="text-sm font-semibold opacity-95">Batman Merkez</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <a
              href={`tel:${phoneNumber}`}
              className="flex items-center gap-2 bg-primary text-secondary px-5 py-3 rounded-lg hover:bg-opacity-90 transition-all font-bold text-base shadow-md hover:shadow-lg"
            >
              <Phone size={20} />
              <span className="hidden sm:inline">Ara</span>
            </a>
            <a
              href={`https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 bg-primary text-secondary px-5 py-3 rounded-lg hover:bg-opacity-90 transition-all font-bold text-base shadow-md hover:shadow-lg"
            >
              <MessageCircle size={20} />
              <span className="hidden sm:inline">WhatsApp</span>
            </a>
          </div>
        </div>
      </div>
    </header>
  )
}
