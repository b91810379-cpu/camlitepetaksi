import Image from 'next/image'

export default function HeroSection() {
  return (
    <section className="relative w-full h-96 md:h-[500px] overflow-hidden">
      <Image
        src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG-20260731-WA0003-9C0D1b2GJez9ReUxbXRqHyW3gQ9Y6w.jpg"
        alt="Çamlıtepe Taksi Durağı"
        fill
        className="object-cover"
        priority
      />
      <div className="absolute inset-0 bg-black/35 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-4xl md:text-6xl font-black mb-6 text-primary drop-shadow-lg">Çamlıtepe Taksi Durağı</h2>
          <p className="text-xl md:text-2xl font-bold text-white drop-shadow-md">Güvenilir ve Hızlı Hizmet</p>
        </div>
      </div>
    </section>
  )
}
