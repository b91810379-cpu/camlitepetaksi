import { Phone, MapPin, Clock, MessageCircle } from 'lucide-react'

export default function InfoSection() {
  return (
    <section className="py-12 md:py-16 bg-white">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-4xl font-black text-secondary mb-12 text-center tracking-tight">İletişim Bilgileri</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Telefon */}
          <a
            href="tel:05306378449"
            className="bg-gradient-to-br from-primary/10 to-primary/5 border-2 border-primary rounded-lg p-6 hover:shadow-xl transition-all hover:from-primary/20 hover:to-primary/10 group cursor-pointer"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="w-14 h-14 bg-primary rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                <Phone className="text-white" size={28} />
              </div>
              <h3 className="font-black text-secondary text-lg">Telefon</h3>
            </div>
            <p className="text-primary font-black text-2xl">0530 637 84 49</p>
            <p className="text-secondary font-semibold text-sm mt-2">7/24 Hizmet</p>
          </a>

          {/* WhatsApp */}
          <a
            href="https://wa.me/905306378449?text=Merhaba%20taksi%20%C3%A7a%C4%9F%C4%B1rmak%20istiyorum"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-gradient-to-br from-primary/10 to-primary/5 border-2 border-primary rounded-lg p-6 hover:shadow-xl transition-all hover:from-primary/20 hover:to-primary/10 group cursor-pointer"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="w-14 h-14 bg-primary rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                <MessageCircle className="text-white" size={28} />
              </div>
              <h3 className="font-black text-secondary text-lg">WhatsApp</h3>
            </div>
            <p className="text-primary font-black text-2xl">Hemen İlet</p>
            <p className="text-secondary font-semibold text-sm mt-2">Anlık Cevap</p>
          </a>

          {/* Adres */}
          <div className="bg-gradient-to-br from-primary/10 to-primary/5 border-2 border-primary rounded-lg p-6 hover:shadow-xl transition-all hover:from-primary/20 hover:to-primary/10 group">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-14 h-14 bg-primary rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                <MapPin className="text-white" size={28} />
              </div>
              <h3 className="font-black text-secondary text-lg">Adres</h3>
            </div>
            <p className="text-secondary font-black text-lg">Çamlıtepe Mahallesi</p>
            <p className="text-primary font-bold text-sm mt-2">Dünya Hastanesi Önü</p>
            <p className="text-primary font-bold text-sm">Batman Merkez</p>
          </div>

          {/* Çalışma Saatleri */}
          <div className="bg-gradient-to-br from-primary/10 to-primary/5 border-2 border-primary rounded-lg p-6 hover:shadow-xl transition-all hover:from-primary/20 hover:to-primary/10 group">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-14 h-14 bg-primary rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                <Clock className="text-white" size={28} />
              </div>
              <h3 className="font-black text-secondary text-lg">Hizmet</h3>
            </div>
            <p className="text-primary font-black text-2xl">7/24</p>
            <p className="text-secondary font-bold text-sm mt-2">Kesintisiz Hizmet</p>
          </div>
        </div>
      </div>
    </section>
  )
}
